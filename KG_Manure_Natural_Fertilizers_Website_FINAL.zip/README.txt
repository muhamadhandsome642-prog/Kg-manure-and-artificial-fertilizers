KG MANURE & NATURAL FERTILIZERS — WEBSITE
============================================

This version includes:
- Reusable KG company logo (kg-logo.svg)
- Agricultural company positioning
- Product catalogue with starting price of UGX 15,000
- Vision, Mission and Core Values
- Natural fertilizer/manure benefits
- Main branch: Buikwe District
- Branches: Nagojje, Katoogo and Waluga, Mukono District
- Gallery
- WhatsApp enquiry/order button
- Contact numbers:
  0767 152 008
  0777 105 174
  +256 789 772 537

Open index.html in a browser to preview.
Keep all files in the same folder.

For a final commercial launch, replace sample stock images with the company's own product, packaging and farm photographs, and confirm exact product names, pack sizes and prices.
